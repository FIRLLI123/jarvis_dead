package com.example.barcode.helper;

public class Config {

    //public static String host = "http://192.168.100.159/sales/";
    //public static String host = "https://webandroidfirlli.000webhostapp.com/reka2/";
    public static String host = "http://rekamitrayasa.com/reka/";



    //public static String img = "http://192.168.100.159/reka3/img";
    public static String img = "http://rekamitrayasa.com/reka/img";
}

