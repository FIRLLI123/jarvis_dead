package com.example.barcode;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.bumptech.glide.Glide;
import com.example.barcode.helper.Config;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;



import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    // View Object
    private Button buttonScan, btnkeLogin;
    private TextView idoutlet1, namaoutlet1, namasales1, tanggalabsen1, jamabsen1, namasalesbackup2, tanggal2, jam2, outlettutup1;

    private ProgressDialog pDialog;

    private Context context;

    EditText namasalesbackup1;
    TextView klikdisini1;

    // dimana y mas tempatnya?

    private static final String[] countries = new String[]{
            "ANWAR", "YUSUF MAULANA", "AKMAL MAULANA", "ARDIANSYAH", "M ZAIRIN", "TUTUT SETIADI",
            "ROHMAT", "M SANUSI", "SARYONO", "KRISTIAN", "RAHMATULLAH", "SULAIMAN", "M SIHABUDIN",
            "ADITYA LUTVI", "SAEFUNAJIB", "ASEP NURKOMARUDIN", "M JOFAN", "SYARIF HIDAYAT", "ANCHE ARIS SUGIYANTO",
            "ALEX SURYA PUTRA", "MUHAMMAD ZIHAD", "RIVAI CAHYA NUGRAHA", "ABDUL ROZAK", "IBNU HARYOTO",
            "EKO SURYANTO", "RAHMADHANI NUGROHO","RAHADIAN PUTRA", "FIQIH ABDULLAH", "SUHENDRA",
            "LUCKY DARMAWAN", "DIMAS ARI WICAKSONO", "RENDI H", "AANG PURNAMA", "INDRA RUKMANA",
            "OKA KAMARULSYAH", "M HANIF","KETUT ANOM JATMIKA","CHANDRA HADI LESMANA","ANDY BUDIMAN","FIRLLI"
    };

    //qr code scanner object
    private IntentIntegrator intentIntegrator;
    AutoCompleteTextView edittext991;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        context = MainActivity.this;
        pDialog = new ProgressDialog(context);


        klikdisini1 = (TextView) findViewById(R.id.klikdisini);


        edittext991 = (AutoCompleteTextView) findViewById(R.id.edittext99);
        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, countries);
        edittext991.setAdapter(adapter);



        // initialize object
        buttonScan = (Button) findViewById(R.id.buttonScan);
        btnkeLogin = (Button) findViewById(R.id.btnkelogin);
        idoutlet1 = (TextView) findViewById(R.id.idoutlet);
        namaoutlet1 = (TextView) findViewById(R.id.namaoutlet);
        namasales1 = (TextView) findViewById(R.id.namasales);
        namasalesbackup1 = (EditText) findViewById(R.id.namasalesbackup);
        tanggalabsen1 = (TextView) findViewById(R.id.tanggalabsen);
        jamabsen1 = (TextView) findViewById(R.id.jamabsen);
        outlettutup1 = (TextView) findViewById(R.id.outlettutup);




        namasalesbackup2 = (TextView) findViewById(R.id.namasalesbackupkunjungan); //namaoutlet
        tanggal2 = (TextView) findViewById(R.id.tanggalkunjungan); //namaoutlet
        jam2 = (TextView) findViewById(R.id.jamkunjungan); //namaoutlet

        // attaching onclickListener
        buttonScan.setOnClickListener(this);


        btnkeLogin.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                if (idoutlet1.getText().toString().length() == 0) {                    //1
                    //jika form Email belum di isi / masih kosong
                    //p0k1_i.setError("Kilometer harus diisi");
                    Toast.makeText(getApplicationContext(), "Silahkan Scan Terlebih Dahulu", Toast.LENGTH_LONG).show();
                }else if(namasalesbackup1.getText().toString().length() == 0) {
                                    //1
                    //jika form Email belum di isi / masih kosong
                    //p0k1_i.setError("Kilometer harus diisi");
                    namasalesbackup1.setError("harus diisi");Toast.makeText(getApplicationContext(), "Kolom Sales Backup Tidak Boleh Kosong", Toast.LENGTH_LONG).show();

                } else {
                    save();

                    String a = namasales1.getText().toString();
                    String b = idoutlet1.getText().toString();
                    String c = namaoutlet1.getText().toString();
                    Intent i = new Intent(getApplicationContext(), Login.class);
                    i.putExtra("namasales", "" + a + "");
                    i.putExtra("idoutlet", "" + b + "");
                    i.putExtra("namaoutlet", "" + c + "");
                    startActivity(i);
                }
            }
        });





        tanggalabsen1.setText(getCurrentDate());
        jamabsen1.setText(jamotomatis());
        //edittext();




        klikdisini1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {

                showCustomDialog();

            }

        });

    }
//dialog outlet tutup
    private void showCustomDialog() {
        final Dialog dialog = new Dialog(this);
        //Mengeset judul dialog
        dialog.setTitle("Add Outlet");

        //Mengeset layout
        dialog.setContentView(R.layout.outlettutup);

        //Membuat agar dialog tidak hilang saat di click di area luar dialog
        dialog.setCanceledOnTouchOutside(false);

        //Membuat dialog agar berukuran responsive
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = metrics.widthPixels;
        dialog.getWindow().setLayout((6 * width) / 7, LinearLayout.LayoutParams.WRAP_CONTENT);

        Button cancelButton = (Button) dialog.findViewById(R.id.button_cancel);
        Button saveButton = (Button) dialog.findViewById(R.id.button_save);
        Button caritutup1 = (Button) dialog.findViewById(R.id.caritutup);
        EditText idoutlettutup1 = (EditText) dialog.findViewById(R.id.idoutlettutup);
        TextView namaoutlettutup1 = (TextView) dialog.findViewById(R.id.namaoutlettutup);
        TextView namasalestutup1 = (TextView) dialog.findViewById(R.id.namasalestutup);
        TextView tanggaltutup1 = (TextView) dialog.findViewById(R.id.tanggaltutup);


        tanggaltutup1.setText(getCurrentDate());

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(idoutlettutup1.getText().toString().length()==0) {                    //1
                    //jika form Email belum di isi / masih kosong
                    idoutlettutup1.setError("ID Outlet harus diisi");
                }else {
                        pDialog.setMessage("Outlet Tutup Di Process...");
                        showDialog();
                        AndroidNetworking.post(Config.host + "outlettutup.php")
                                .addBodyParameter("idoutlet", idoutlettutup1.getText().toString())
                                .addBodyParameter("namaoutlet", namaoutlettutup1.getText().toString())
                                .addBodyParameter("namasales", namasalestutup1.getText().toString())
                                .addBodyParameter("tanggal", tanggaltutup1.getText().toString())
                                .setPriority(Priority.MEDIUM)
                                .build()

                                .getAsJSONObject(new JSONObjectRequestListener() {
                                    @Override
                                    public void onResponse(JSONObject response) {
                                        // do anything with response

                                        Log.d("response", response.toString());

                                        if (response.optString("response").toString().equals("success")) {
                                            hideDialog();
                                            //gotoCourseActivity();
                                            Toast.makeText(getApplicationContext(), "Berhasil Simpan",
                                                    Toast.LENGTH_LONG).show();


                                        } else {
                                            hideDialog();
                                            Toast.makeText(getApplicationContext(), "failed",
                                                    Toast.LENGTH_LONG).show();
                                        }
                                    }

                                    @Override
                                    public void onError(ANError error) {
                                        // handle error
                                    }
                                });

                        //dialog.dismiss();
                    }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        caritutup1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idoutlettutup1.getText().toString().length() == 0) {                    //1
                    //jika form Email belum di isi / masih kosong
                    idoutlettutup1.setError("ID Outlet harus diisi");
                } else {
                    AndroidNetworking.post(Config.host + "dataoutlet.php")
                            .addBodyParameter("idoutlet", idoutlettutup1.getText().toString())
                            //.addBodyParameter("bulan1", bulan1.getText().toString())
                            //.addBodyParameter("bulan2", bulan2.getText().toString())
                            .setPriority(Priority.MEDIUM)
                            .build()
                            .getAsJSONObject(new JSONObjectRequestListener() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    // do anything with response


                                    NumberFormat rupiahFormat = NumberFormat.getInstance(Locale.GERMANY);
                                    //idoutmenu1.setText((response.optString("idoutlet")));
                                    namaoutlettutup1.setText((response.optString("namaoutlet")));
                                    namasalestutup1.setText((response.optString("namasales")));
                                    //.setText((response.optString("jam")));


                                }

                                @Override
                                public void onError(ANError error) {

                                }
                            });


                    //dialog.dismiss();
                }
            }
        });


        //Menampilkan custom dialog
        dialog.show();

    }







    // Mendapatkan hasil scan


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null){
            if (result.getContents() == null){
                Toast.makeText(this, "Hasil tidak ditemukan", Toast.LENGTH_SHORT).show();
            }else{
                // jika qrcode berisi data
                try{
                    // converting the data json
                    JSONObject object = new JSONObject(result.getContents());
                    // atur nilai ke textviews
                    idoutlet1.setText(object.getString("idoutlet"));
                    namaoutlet1.setText(object.getString("namaoutlet"));
                    namasales1.setText(object.getString("namasales"));
                    namasalesbackup1.setText(object.getString("namasalesbackup"));
                    edittext991.setText(object.getString("namasalesbackup"));

                    kunjunganterakhir();

                }catch (JSONException e){
                    e.printStackTrace();
                    // jika format encoded tidak sesuai maka hasil
                    // ditampilkan ke toast
                    Toast.makeText(this, result.getContents(), Toast.LENGTH_SHORT).show();
                }


            }
        }else{
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onClick(View v) {
        // inisialisasi IntentIntegrator(scanQR)
        intentIntegrator = new IntentIntegrator(this);
        intentIntegrator.initiateScan();
    }


    private void save() {
        pDialog.setMessage("Absen Process...");
        showDialog();
        AndroidNetworking.post(Config.host + "absen.php")
                .addBodyParameter("idoutlet", idoutlet1.getText().toString())
                .addBodyParameter("namaoutlet", namaoutlet1.getText().toString())
                .addBodyParameter("namasalesbackup", edittext991.getText().toString())
                .addBodyParameter("tanggal", tanggalabsen1.getText().toString())
                .addBodyParameter("jam", jamabsen1.getText().toString())
                .setPriority(Priority.MEDIUM)
                .build()

                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // do anything with response

                        Log.d("response", response.toString());

                        if (response.optString("response").toString().equals("success")) {
                            hideDialog();
                            //gotoCourseActivity();
                            Toast.makeText(getApplicationContext(), "Berhasil Absen",
                                    Toast.LENGTH_LONG).show();


                        } else {
                            hideDialog();
                            Toast.makeText(getApplicationContext(), "failed",
                                    Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }


    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    private void gotoCourseActivity() {



    }


    public String jamotomatis(){
        Calendar c1 = Calendar.getInstance();
        //SimpleDateFormat sdf1 = new SimpleDateFormat("d/M/yyyy h:m:s a");
        SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");
        String strdate1 = sdf1.format(c1.getTime());
        return strdate1;



    }

    public String getCurrentDate(){
        final Calendar c = Calendar.getInstance();
        int year, month, day;
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DATE);
        SimpleDateFormat contoh1 = new SimpleDateFormat("EEEE");

        String hariotomatis = contoh1.format(c.getTime());

        //return day +"/" + (month+1) + "/" + year;
        //return (month+1) +"/" + day + "/" + year;
        return year +"/" + (month+1) + "/" + day;
    }



    private void kunjunganterakhir() {

        AndroidNetworking.post(Config.host + "kunjunganterakhir.php")
                .addBodyParameter("idoutlet", idoutlet1.getText().toString())
                //.addBodyParameter("bulan1", bulan1.getText().toString())
                //.addBodyParameter("bulan2", bulan2.getText().toString())
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // do anything with response


                        NumberFormat rupiahFormat = NumberFormat.getInstance(Locale.GERMANY);
                        //idoutmenu1.setText((response.optString("idoutlet")));
                        namasalesbackup2.setText((response.optString("namasalesbackup")));
                        tanggal2.setText((response.optString("tanggal")));
                        jam2.setText((response.optString("jam")));



                    }

                    @Override
                    public void onError(ANError error) {

                    }
                });


    }






}