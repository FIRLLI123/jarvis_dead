package com.example.barcode.API;



public class Server {

    public static final String API = "http://core-tech.id/percoba/cobaprint/";

    //data
    public static final String list_bayar = API+"data_select.php";

}

